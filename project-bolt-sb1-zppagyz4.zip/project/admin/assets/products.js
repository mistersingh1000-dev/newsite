import { checkAdminAuth, signOut, supabase, logAdminActivity } from '../auth.js';

let adminData = null;
let allProducts = [];

async function init() {
    adminData = await checkAdminAuth();
    if (!adminData) return;

    await loadProducts();
    await loadCategories();
    setupEventListeners();
}

async function loadProducts() {
    try {
        const { data, error } = await supabase
            .from('products')
            .select(`
                *,
                product_images(image_url, is_primary)
            `)
            .order('created_at', { ascending: false });

        if (error) throw error;

        allProducts = data;
        renderProducts(allProducts);

    } catch (error) {
        console.error('Error loading products:', error);
        document.getElementById('products-tbody').innerHTML =
            '<tr><td colspan="7" style="text-align: center; padding: 40px;">Failed to load products</td></tr>';
    }
}

function renderProducts(products) {
    const tbody = document.getElementById('products-tbody');

    if (!products || products.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 40px;">No products found</td></tr>';
        return;
    }

    tbody.innerHTML = products.map(product => {
        const primaryImage = product.product_images?.find(img => img.is_primary) || product.product_images?.[0];
        const imageUrl = primaryImage?.image_url || product.thumbnail || '/placeholder-product.jpg';

        return `
            <tr>
                <td>
                    <img src="${imageUrl}" alt="${product.title}" class="product-image-thumb" onerror="this.src='/placeholder-product.jpg'">
                </td>
                <td><strong>${product.title}</strong></td>
                <td>${product.sku || '-'}</td>
                <td>
                    ${product.sale_price ? `
                        <strong>₹${parseFloat(product.sale_price).toLocaleString('en-IN')}</strong><br>
                        <small style="text-decoration: line-through; color: #999;">₹${parseFloat(product.regular_price || 0).toLocaleString('en-IN')}</small>
                    ` : `
                        <strong>₹${parseFloat(product.regular_price || 0).toLocaleString('en-IN')}</strong>
                    `}
                </td>
                <td>${product.stock_quantity || 0}</td>
                <td>
                    <span class="status-badge ${product.published ? 'status-completed' : 'status-pending'}">
                        ${product.published ? 'Published' : 'Draft'}
                    </span>
                    ${product.is_featured ? '<span class="status-badge status-processing" style="margin-left: 4px;">Featured</span>' : ''}
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-icon edit" onclick="editProduct(${product.id})" title="Edit">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                        </button>
                        <button class="btn-icon delete" onclick="deleteProduct(${product.id}, '${product.title}')" title="Delete">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"></polyline>
                                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                            </svg>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

async function loadCategories() {
    try {
        const { data } = await supabase
            .from('product_categories_new')
            .select('category_name')
            .order('category_name');

        const categories = [...new Set(data?.map(c => c.category_name) || [])];
        const select = document.getElementById('category-filter');

        categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat;
            option.textContent = cat;
            select.appendChild(option);
        });

    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

function setupEventListeners() {
    document.getElementById('search-input').addEventListener('input', filterProducts);
    document.getElementById('category-filter').addEventListener('change', filterProducts);
    document.getElementById('status-filter').addEventListener('change', filterProducts);
    document.getElementById('product-form').addEventListener('submit', handleProductSubmit);
}

function filterProducts() {
    const search = document.getElementById('search-input').value.toLowerCase();
    const category = document.getElementById('category-filter').value;
    const status = document.getElementById('status-filter').value;

    const filtered = allProducts.filter(product => {
        const matchesSearch = product.title.toLowerCase().includes(search) ||
                            (product.sku && product.sku.toLowerCase().includes(search));

        const matchesStatus = !status ||
            (status === 'published' && product.published) ||
            (status === 'draft' && !product.published);

        return matchesSearch && matchesStatus;
    });

    renderProducts(filtered);
}

window.openAddProductModal = function() {
    document.getElementById('modal-title').textContent = 'Add New Product';
    document.getElementById('product-form').reset();
    document.getElementById('product-id').value = '';
    document.getElementById('product-published').checked = true;
    document.getElementById('product-stock').value = '100';
    document.getElementById('product-modal').classList.add('show');
};

window.closeProductModal = function() {
    document.getElementById('product-modal').classList.remove('show');
};

window.editProduct = async function(productId) {
    const product = allProducts.find(p => p.id === productId);
    if (!product) return;

    document.getElementById('modal-title').textContent = 'Edit Product';
    document.getElementById('product-id').value = product.id;
    document.getElementById('product-title').value = product.title;
    document.getElementById('product-sku').value = product.sku || '';
    document.getElementById('product-regular-price').value = product.regular_price || '';
    document.getElementById('product-sale-price').value = product.sale_price || '';
    document.getElementById('product-short-desc').value = product.short_description || '';
    document.getElementById('product-stock').value = product.stock_quantity || 0;
    document.getElementById('product-thumbnail').value = product.thumbnail || '';
    document.getElementById('product-published').checked = product.published;
    document.getElementById('product-featured').checked = product.is_featured;

    document.getElementById('product-modal').classList.add('show');
};

async function handleProductSubmit(e) {
    e.preventDefault();

    const productId = document.getElementById('product-id').value;
    const title = document.getElementById('product-title').value;
    const sku = document.getElementById('product-sku').value;
    const regularPrice = parseFloat(document.getElementById('product-regular-price').value);
    const salePrice = parseFloat(document.getElementById('product-sale-price').value) || null;
    const shortDesc = document.getElementById('product-short-desc').value;
    const stock = parseInt(document.getElementById('product-stock').value) || 0;
    const thumbnail = document.getElementById('product-thumbnail').value;
    const published = document.getElementById('product-published').checked;
    const featured = document.getElementById('product-featured').checked;

    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

    const productData = {
        title,
        slug,
        sku: sku || null,
        regular_price: regularPrice,
        sale_price: salePrice,
        short_description: shortDesc,
        stock_quantity: stock,
        stock_status: stock > 0 ? 'in_stock' : 'out_of_stock',
        thumbnail: thumbnail || null,
        published,
        is_featured: featured
    };

    try {
        if (productId) {
            // Update existing product
            const { error } = await supabase
                .from('products')
                .update(productData)
                .eq('id', productId);

            if (error) throw error;

            await logAdminActivity('update_product', 'product', productId, { title });
            alert('Product updated successfully!');
        } else {
            // Create new product
            const { error } = await supabase
                .from('products')
                .insert(productData);

            if (error) throw error;

            await logAdminActivity('create_product', 'product', null, { title });
            alert('Product created successfully!');
        }

        closeProductModal();
        await loadProducts();

    } catch (error) {
        console.error('Error saving product:', error);
        alert('Failed to save product: ' + error.message);
    }
}

window.deleteProduct = async function(productId, productTitle) {
    if (!confirm(`Are you sure you want to delete "${productTitle}"?`)) {
        return;
    }

    try {
        const { error } = await supabase
            .from('products')
            .delete()
            .eq('id', productId);

        if (error) throw error;

        await logAdminActivity('delete_product', 'product', productId, { title: productTitle });
        alert('Product deleted successfully!');
        await loadProducts();

    } catch (error) {
        console.error('Error deleting product:', error);
        alert('Failed to delete product: ' + error.message);
    }
};

window.handleSignOut = signOut;

init();
