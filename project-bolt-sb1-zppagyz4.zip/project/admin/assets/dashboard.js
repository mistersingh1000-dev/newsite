import { checkAdminAuth, signOut, supabase } from '../auth.js';

let adminData = null;

async function init() {
    adminData = await checkAdminAuth();
    if (!adminData) return;

    updateAdminInfo();
    await loadDashboardStats();
    await loadRecentOrders();
}

function updateAdminInfo() {
    const nameElement = document.getElementById('admin-name');
    const headerNameElement = document.getElementById('header-admin-name');
    const roleElement = document.getElementById('admin-role');
    const initialsElement = document.getElementById('admin-initials');

    const fullName = adminData.admin.full_name || adminData.user.email;
    const initials = fullName.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

    if (nameElement) nameElement.textContent = fullName;
    if (headerNameElement) headerNameElement.textContent = fullName;
    if (roleElement) roleElement.textContent = adminData.admin.role.replace('_', ' ');
    if (initialsElement) initialsElement.textContent = initials;
}

async function loadDashboardStats() {
    try {
        // Get total products
        const { count: productsCount } = await supabase
            .from('products')
            .select('*', { count: 'exact', head: true });

        document.getElementById('total-products').textContent = productsCount || 0;

        // Get total orders
        const { count: ordersCount } = await supabase
            .from('orders')
            .select('*', { count: 'exact', head: true });

        document.getElementById('total-orders').textContent = ordersCount || 0;

        // Get total customers
        const { count: customersCount } = await supabase
            .from('users')
            .select('*', { count: 'exact', head: true });

        document.getElementById('total-customers').textContent = customersCount || 0;

        // Calculate total revenue
        const { data: orders } = await supabase
            .from('orders')
            .select('total_amount')
            .eq('payment_status', 'paid');

        const totalRevenue = orders?.reduce((sum, order) => sum + parseFloat(order.total_amount || 0), 0) || 0;
        document.getElementById('total-revenue').textContent = `₹${totalRevenue.toLocaleString('en-IN')}`;

    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

async function loadRecentOrders() {
    try {
        const { data: orders, error } = await supabase
            .from('orders')
            .select('*')
            .order('created_at', { ascending: false })
            .limit(5);

        if (error) throw error;

        const tbody = document.getElementById('recent-orders');

        if (!orders || orders.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 40px;">No orders yet</td></tr>';
            return;
        }

        tbody.innerHTML = orders.map(order => `
            <tr>
                <td><strong>${order.order_number}</strong></td>
                <td>${order.customer_name}</td>
                <td><strong>₹${parseFloat(order.total_amount || 0).toLocaleString('en-IN')}</strong></td>
                <td><span class="status-badge status-${order.payment_status}">${order.payment_status}</span></td>
                <td>${new Date(order.created_at).toLocaleDateString('en-IN')}</td>
            </tr>
        `).join('');

    } catch (error) {
        console.error('Error loading recent orders:', error);
        document.getElementById('recent-orders').innerHTML =
            '<tr><td colspan="5" style="text-align: center; padding: 40px;">Failed to load orders</td></tr>';
    }
}

window.handleSignOut = signOut;

init();
