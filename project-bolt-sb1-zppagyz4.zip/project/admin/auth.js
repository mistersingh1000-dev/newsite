import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export async function checkAdminAuth() {
  const { data: { session } } = await supabase.auth.getSession();

  if (!session) {
    window.location.href = '/admin/login.html';
    return null;
  }

  const { data: adminUser, error } = await supabase
    .from('admin_users')
    .select('*')
    .eq('id', session.user.id)
    .eq('is_active', true)
    .maybeSingle();

  if (error || !adminUser) {
    await supabase.auth.signOut();
    window.location.href = '/admin/login.html';
    return null;
  }

  return {
    user: session.user,
    admin: adminUser
  };
}

export async function logAdminActivity(action, entityType, entityId, details = {}) {
  const { data: { session } } = await supabase.auth.getSession();

  if (!session) return;

  await supabase
    .from('admin_activity_logs')
    .insert({
      admin_id: session.user.id,
      action,
      entity_type: entityType,
      entity_id: entityId,
      details
    });
}

export async function signOut() {
  const { data: { session } } = await supabase.auth.getSession();

  if (session) {
    await logAdminActivity('logout', 'auth', null);
  }

  await supabase.auth.signOut();
  window.location.href = '/admin/login.html';
}
