/*
  # Add Insert Policies for Products

  ## Changes
  - Add policies to allow inserting products and related data
  - For now, allow public insert (can be restricted later based on auth)
*/

-- Allow inserting products (can be restricted to authenticated users later)
CREATE POLICY "Allow insert products"
  ON products FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow update products"
  ON products FOR UPDATE
  USING (true);

-- Allow inserting product images
CREATE POLICY "Allow insert product images"
  ON product_images FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow delete product images"
  ON product_images FOR DELETE
  USING (true);

-- Allow inserting product categories
CREATE POLICY "Allow insert product categories"
  ON product_categories_new FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow delete product categories"
  ON product_categories_new FOR DELETE
  USING (true);

-- Allow inserting product tags
CREATE POLICY "Allow insert product tags"
  ON product_tags_new FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow delete product tags"
  ON product_tags_new FOR DELETE
  USING (true);

-- Allow inserting product attributes
CREATE POLICY "Allow insert product attributes"
  ON product_attributes FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Allow delete product attributes"
  ON product_attributes FOR DELETE
  USING (true);
