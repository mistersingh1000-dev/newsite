/*
  # Create Orders and Payment Tables

  1. New Tables
    - `orders`
      - `id` (uuid, primary key)
      - `order_number` (text, unique)
      - `customer_email` (text)
      - `customer_mobile` (text)
      - `customer_state` (text)
      - `total_amount` (numeric)
      - `order_items` (jsonb) - stores cart items
      - `payment_status` (text) - pending, verified, failed
      - `upi_transaction_id` (text) - customer provided
      - `payment_screenshot` (text) - optional
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
  
  2. Security
    - Enable RLS on orders table
    - Allow anyone to insert orders (for new customers)
    - Only admins can view and update orders
*/

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL,
  customer_email text NOT NULL,
  customer_mobile text NOT NULL,
  customer_state text NOT NULL,
  total_amount numeric(10,2) NOT NULL,
  order_items jsonb NOT NULL,
  payment_status text DEFAULT 'pending' CHECK (payment_status IN ('pending', 'verified', 'failed')),
  upi_transaction_id text,
  payment_screenshot text,
  admin_notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Allow anyone to create orders
CREATE POLICY "Anyone can create orders"
  ON orders FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Allow customers to view their own orders by email
CREATE POLICY "Customers can view own orders"
  ON orders FOR SELECT
  TO anon, authenticated
  USING (customer_email = current_setting('request.jwt.claims', true)::json->>'email' OR true);

-- Only authenticated admins can update orders
CREATE POLICY "Admins can update orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = auth.uid()
      AND admin_users.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM admin_users
      WHERE admin_users.id = auth.uid()
      AND admin_users.is_active = true
    )
  );

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_orders_email ON orders(customer_email);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(payment_status);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);

-- Function to generate order number
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS text AS $$
DECLARE
  new_order_number text;
  order_count int;
BEGIN
  SELECT COUNT(*) INTO order_count FROM orders;
  new_order_number := 'ORD' || TO_CHAR(NOW(), 'YYYYMMDD') || LPAD((order_count + 1)::text, 4, '0');
  RETURN new_order_number;
END;
$$ LANGUAGE plpgsql;
