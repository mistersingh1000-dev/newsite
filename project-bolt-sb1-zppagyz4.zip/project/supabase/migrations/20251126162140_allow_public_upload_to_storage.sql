/*
  # Allow Public Upload to Product Images Storage
  
  1. Changes
    - Allow public (unauthenticated) users to upload images
    - This is needed for the migration script
    - Can be reverted after migration is complete
  
  2. Security Note
    - This is a temporary policy for migration purposes
    - In production, you may want to restrict uploads to authenticated users only
*/

-- Drop existing authenticated upload policy
DROP POLICY IF EXISTS "Authenticated users can upload images" ON storage.objects;

-- Allow public uploads (for migration script)
CREATE POLICY "Public can upload images"
ON storage.objects FOR INSERT
TO public
WITH CHECK (bucket_id = 'product-images');

-- Also update other policies to work with public
DROP POLICY IF EXISTS "Authenticated users can update images" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can delete images" ON storage.objects;

CREATE POLICY "Public can update images"
ON storage.objects FOR UPDATE
TO public
USING (bucket_id = 'product-images');

CREATE POLICY "Public can delete images"
ON storage.objects FOR DELETE
TO public
USING (bucket_id = 'product-images');
