/*
  # Make Price Fields More Flexible

  ## Changes
  - Make regular_price nullable with default value
  - Make short_description not required
*/

ALTER TABLE products ALTER COLUMN regular_price DROP NOT NULL;
ALTER TABLE products ALTER COLUMN regular_price SET DEFAULT 0;
ALTER TABLE products ALTER COLUMN short_description DROP NOT NULL;
