/*
  # Extend Products Table for WordPress Product Import

  ## Changes
  - Add missing columns to existing products table for WordPress compatibility
  - Create new tables for product images, categories, tags, and attributes
  - Add indexes for better performance
  - Set up Row Level Security policies

  ## New Columns for products table
  - `product_type` - Type of product (simple, variable, variation, downloadable)
  - `parent_id` - For product variations
  - `brand` - Product brand
  - `position` - Display order
  - `published` - Publication status
  - `featured` - Featured product flag
  - `stock_quantity` - Numeric stock count
  - `description` - Full HTML description (maps to long_description)

  ## New Tables
  - `product_images` - Multiple images per product
  - `product_categories_new` - Hierarchical categories
  - `product_tags_new` - Product tags
  - `product_attributes` - Product attributes (color, size, etc.)
*/

-- Add new columns to products table if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'products' AND column_name = 'product_type') THEN
    ALTER TABLE products ADD COLUMN product_type text DEFAULT 'simple';
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'products' AND column_name = 'parent_id') THEN
    ALTER TABLE products ADD COLUMN parent_id bigint;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'products' AND column_name = 'brand') THEN
    ALTER TABLE products ADD COLUMN brand text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'products' AND column_name = 'position') THEN
    ALTER TABLE products ADD COLUMN position integer DEFAULT 0;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'products' AND column_name = 'published') THEN
    ALTER TABLE products ADD COLUMN published boolean DEFAULT true;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'products' AND column_name = 'stock_quantity') THEN
    ALTER TABLE products ADD COLUMN stock_quantity integer DEFAULT 0;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'products' AND column_name = 'description') THEN
    ALTER TABLE products ADD COLUMN description text;
  END IF;
END $$;

-- Create product_images table
CREATE TABLE IF NOT EXISTS product_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id bigint NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  position integer DEFAULT 0,
  is_primary boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create product_categories_new table (separate from existing category field)
CREATE TABLE IF NOT EXISTS product_categories_new (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id bigint NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  category_name text NOT NULL,
  parent_category text,
  created_at timestamptz DEFAULT now()
);

-- Create product_tags_new table
CREATE TABLE IF NOT EXISTS product_tags_new (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id bigint NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  tag text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create product_attributes table
CREATE TABLE IF NOT EXISTS product_attributes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id bigint NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  attribute_name text NOT NULL,
  attribute_value text NOT NULL,
  visible boolean DEFAULT true,
  position integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_products_product_type ON products(product_type);
CREATE INDEX IF NOT EXISTS idx_products_published ON products(published) WHERE published = true;
CREATE INDEX IF NOT EXISTS idx_products_parent_id ON products(parent_id) WHERE parent_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_product_images_product_id ON product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_product_categories_new_product_id ON product_categories_new(product_id);
CREATE INDEX IF NOT EXISTS idx_product_categories_new_category ON product_categories_new(category_name);
CREATE INDEX IF NOT EXISTS idx_product_tags_new_product_id ON product_tags_new(product_id);
CREATE INDEX IF NOT EXISTS idx_product_tags_new_tag ON product_tags_new(tag);
CREATE INDEX IF NOT EXISTS idx_product_attributes_product_id ON product_attributes(product_id);

-- Enable Row Level Security on new tables
ALTER TABLE product_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_categories_new ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_tags_new ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_attributes ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for public read access
CREATE POLICY "Anyone can view product images"
  ON product_images FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM products
      WHERE products.id = product_images.product_id
      AND products.published = true
    )
  );

CREATE POLICY "Anyone can view product categories"
  ON product_categories_new FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM products
      WHERE products.id = product_categories_new.product_id
      AND products.published = true
    )
  );

CREATE POLICY "Anyone can view product tags"
  ON product_tags_new FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM products
      WHERE products.id = product_tags_new.product_id
      AND products.published = true
    )
  );

CREATE POLICY "Anyone can view product attributes"
  ON product_attributes FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM products
      WHERE products.id = product_attributes.product_id
      AND products.published = true
    )
  );
