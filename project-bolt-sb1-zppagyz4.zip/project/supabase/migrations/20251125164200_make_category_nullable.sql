/*
  # Make Category Field Nullable

  ## Changes
  - Make the category field nullable to allow importing products without categories
  - Products will use the new product_categories_new table for category relationships
*/

ALTER TABLE products ALTER COLUMN category DROP NOT NULL;
