/*
  # Add Missing Columns to Orders Table

  1. Changes
    - Add customer_mobile column
    - Add customer_state column
    - Add order_items jsonb column
    - Add upi_transaction_id column
    - Add payment_screenshot column
    - Add admin_notes column
  
  2. Notes
    - Uses IF NOT EXISTS to prevent errors if columns already exist
*/

-- Add customer_mobile if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'customer_mobile'
  ) THEN
    ALTER TABLE orders ADD COLUMN customer_mobile text;
  END IF;
END $$;

-- Add customer_state if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'customer_state'
  ) THEN
    ALTER TABLE orders ADD COLUMN customer_state text;
  END IF;
END $$;

-- Add order_items if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'order_items'
  ) THEN
    ALTER TABLE orders ADD COLUMN order_items jsonb;
  END IF;
END $$;

-- Add upi_transaction_id if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'upi_transaction_id'
  ) THEN
    ALTER TABLE orders ADD COLUMN upi_transaction_id text;
  END IF;
END $$;

-- Add payment_screenshot if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'payment_screenshot'
  ) THEN
    ALTER TABLE orders ADD COLUMN payment_screenshot text;
  END IF;
END $$;

-- Add admin_notes if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'admin_notes'
  ) THEN
    ALTER TABLE orders ADD COLUMN admin_notes text;
  END IF;
END $$;

-- Create indexes for faster lookups
CREATE INDEX IF NOT EXISTS idx_orders_mobile ON orders(customer_mobile);
CREATE INDEX IF NOT EXISTS idx_orders_state ON orders(customer_state);
