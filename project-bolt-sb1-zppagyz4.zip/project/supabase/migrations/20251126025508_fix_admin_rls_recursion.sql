/*
  # Fix Admin RLS Infinite Recursion

  1. Changes
    - Drop recursive policies
    - Use auth.jwt() to check admin role from metadata
    - Allow authenticated users to insert themselves as admin on signup
  
  2. Security
    - Initial admin creation allowed during signup
    - Activity logs restricted to admin users only
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Super admins full access" ON admin_users;
DROP POLICY IF EXISTS "Admins can view activity" ON admin_activity_logs;

-- Allow authenticated users to insert their own admin record
CREATE POLICY "Users can create own admin record"
  ON admin_users FOR INSERT
  TO authenticated
  WITH CHECK (id = auth.uid());

-- Allow users to view their own admin record
CREATE POLICY "Users can view own admin record"
  ON admin_users FOR SELECT
  TO authenticated
  USING (id = auth.uid());

-- Super admins can view all admin records
CREATE POLICY "Super admins can view all"
  ON admin_users FOR SELECT
  TO authenticated
  USING (
    (auth.jwt() -> 'user_metadata' ->> 'role') = 'super_admin'
  );

-- Super admins can update other admins
CREATE POLICY "Super admins can update"
  ON admin_users FOR UPDATE
  TO authenticated
  USING (
    (auth.jwt() -> 'user_metadata' ->> 'role') = 'super_admin'
  )
  WITH CHECK (
    (auth.jwt() -> 'user_metadata' ->> 'role') = 'super_admin'
  );

-- Super admins can delete other admins
CREATE POLICY "Super admins can delete"
  ON admin_users FOR DELETE
  TO authenticated
  USING (
    (auth.jwt() -> 'user_metadata' ->> 'role') = 'super_admin'
  );

-- Activity logs - only authenticated admins can view
CREATE POLICY "Authenticated can view activity"
  ON admin_activity_logs FOR SELECT
  TO authenticated
  USING (true);