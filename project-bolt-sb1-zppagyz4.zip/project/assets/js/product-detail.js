import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const urlParams = new URLSearchParams(window.location.search);
const productId = urlParams.get('id');

document.addEventListener('DOMContentLoaded', async () => {
  if (!productId) {
    window.location.href = '/products.html';
    return;
  }

  await loadProductDetails();
});

async function loadProductDetails() {
  try {
    const { data: product, error } = await supabase
      .from('products')
      .select('*')
      .eq('id', productId)
      .eq('published', true)
      .maybeSingle();

    if (error) throw error;

    if (!product) {
      document.getElementById('product-container').innerHTML = `
        <div class="no-product" style="text-align: center; padding: 60px 20px;">
          <h2>Product Not Found</h2>
          <p>The product you're looking for doesn't exist or has been removed.</p>
          <a href="/products.html" class="btn-add-to-cart" style="display: inline-block; margin-top: 20px;">
            Browse All Products
          </a>
        </div>
      `;
      return;
    }

    // Process product data
    product.images = [];
    product.categories = product.category ? [{ category_name: product.category }] : [];
    product.tags = product.tags ? product.tags.map(tag => ({ tag })) : [];

    renderProduct(product);
    setupTabs();

  } catch (error) {
    console.error('Error loading product:', error);
    document.getElementById('product-container').innerHTML = `
      <div class="error" style="text-align: center; padding: 60px 20px;">
        <h2>Failed to Load Product</h2>
        <p>Please try again later</p>
      </div>
    `;
  }
}

function renderProduct(product) {
  const regularPrice = parseFloat(product.regular_price) || 0;
  const salePrice = parseFloat(product.sale_price) || 0;
  const displayPrice = salePrice > 0 ? salePrice : regularPrice;
  const hasDiscount = salePrice > 0 && salePrice < regularPrice;

  const discount = hasDiscount
    ? Math.round(((regularPrice - salePrice) / regularPrice) * 100)
    : 0;

  const savings = hasDiscount ? regularPrice - salePrice : 0;

  const primaryImage = product.images.find(img => img.is_primary) || product.images[0];
  const mainImageUrl = primaryImage?.image_url || product.thumbnail || '/placeholder-product.jpg';

  const categoryName = product.categories[0]?.category_name || 'General';

  document.getElementById('product-breadcrumb').textContent = product.title;
  document.title = `${product.title} - CodeCraft Marketing`;

  const container = document.getElementById('product-container');
  container.innerHTML = `
    <div class="product-main">
      <div class="product-gallery">
        <img src="${mainImageUrl}" alt="${product.title}" class="main-image" id="main-image" onerror="this.src='/placeholder-product.jpg'">
        ${product.images.length > 1 ? `
          <div class="image-thumbnails">
            ${product.images.map((img, idx) => `
              <img src="${img.image_url}" alt="${product.title}" class="thumbnail ${idx === 0 ? 'active' : ''}"
                   onclick="changeImage('${img.image_url}', ${idx})" onerror="this.src='/placeholder-product.jpg'">
            `).join('')}
          </div>
        ` : ''}
      </div>

      <div class="product-details">
        <span class="product-category-badge">${categoryName}</span>
        <h1>${product.title}</h1>

        ${product.short_description ? `
          <p style="color: #666; font-size: 16px; line-height: 1.6; margin-bottom: 20px;">
            ${product.short_description}
          </p>
        ` : ''}

        <div class="product-price-section">
          <div class="price-display">
            <span class="current-price">₹${displayPrice.toLocaleString('en-IN')}</span>
            ${hasDiscount ? `
              <span class="original-price">₹${regularPrice.toLocaleString('en-IN')}</span>
              <span class="discount-badge">${discount}% OFF</span>
            ` : ''}
          </div>
          ${hasDiscount ? `
            <p class="savings">You save: ₹${savings.toLocaleString('en-IN')}</p>
          ` : ''}
        </div>

        <div class="product-features">
          <ul>
            <li>✓ Instant Digital Delivery</li>
            <li>✓ 100% Genuine & Secure</li>
            <li>✓ Easy UPI Payment</li>
            <li>✓ 24/7 Customer Support</li>
          </ul>
        </div>

        <div class="product-actions">
          <button class="btn-add-to-cart" onclick="addToCart(${product.id})">
            Add to Cart
          </button>
          <button class="btn-buy-now" onclick="buyNow(${product.id})">
            Buy Now
          </button>
        </div>

        ${product.tags.length > 0 ? `
          <div class="product-tags">
            ${product.tags.slice(0, 10).map(t => `<span class="tag">${t.tag}</span>`).join('')}
          </div>
        ` : ''}
      </div>
    </div>

    <div class="product-tabs">
      <div class="tab-buttons">
        <button class="tab-button active" data-tab="description">Description</button>
        <button class="tab-button" data-tab="features">Features & Details</button>
        <button class="tab-button" data-tab="delivery">Delivery Info</button>
      </div>

      <div class="tab-content active" id="description">
        <div class="product-description">
          ${product.description || product.short_description || '<p>No description available</p>'}
        </div>
      </div>

      <div class="tab-content" id="features">
        <div class="product-description">
          <h3>Product Details</h3>
          <ul>
            ${product.sku ? `<li><strong>SKU:</strong> ${product.sku}</li>` : ''}
            ${product.brand ? `<li><strong>Brand:</strong> ${product.brand}</li>` : ''}
            <li><strong>Product Type:</strong> ${product.product_type || 'Digital Product'}</li>
            <li><strong>Availability:</strong> ${product.stock_status === 'in_stock' ? 'In Stock' : 'Out of Stock'}</li>
          </ul>
        </div>
      </div>

      <div class="tab-content" id="delivery">
        <div class="product-description">
          <h3>Delivery Information</h3>
          <p>This is a <strong>digital product</strong>. No physical shipping is required.</p>

          <h4>How it works:</h4>
          <ol>
            <li>Complete your order and make payment via UPI</li>
            <li>Our team will verify your payment (usually within 2-24 hours)</li>
            <li>You'll receive the product details via email or WhatsApp</li>
            <li>Access your product instantly</li>
          </ol>

          <h4>Payment Methods:</h4>
          <ul>
            <li>UPI (PhonePe, Google Pay, Paytm)</li>
            <li>Bank Transfer</li>
            <li>Manual Payment Verification</li>
          </ul>

          <h4>Support:</h4>
          <p>For any queries, contact us:</p>
          <ul>
            <li>📞 WhatsApp: +91-7009732517</li>
            <li>📧 Email: mistersingh1000@gmail.com</li>
            <li>✈️ Telegram: @digialmarketing</li>
          </ul>
        </div>
      </div>
    </div>
  `;
}

function setupTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabId = button.dataset.tab;

      // Remove active class from all buttons and content
      document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

      // Add active class to clicked button and corresponding content
      button.classList.add('active');
      document.getElementById(tabId).classList.add('active');
    });
  });
}

window.changeImage = function(imageUrl, index) {
  document.getElementById('main-image').src = imageUrl;
  document.querySelectorAll('.thumbnail').forEach((thumb, idx) => {
    thumb.classList.toggle('active', idx === index);
  });
};

window.addToCart = async function(productId) {
  const { data: product } = await supabase
    .from('products')
    .select('*')
    .eq('id', productId)
    .maybeSingle();

  if (!product) return;

  let cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const existingItem = cart.find(item => item.id === productId);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({
      id: product.id,
      title: product.title,
      price: parseFloat(product.sale_price || product.regular_price) || 0,
      image: product.thumbnail,
      quantity: 1
    });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
  alert(`${product.title} added to cart!`);
};

window.buyNow = async function(productId) {
  await addToCart(productId);
  window.location.href = '/cart.html';
};

function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartCountElement = document.querySelector('.cart-count');
  if (cartCountElement) {
    cartCountElement.textContent = count;
    if (count > 0) {
      cartCountElement.style.display = 'flex';
    }
  }
}

updateCartCount();
