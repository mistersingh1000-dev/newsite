import { supabase } from './supabase-client.js';

let cartItems = [];
let products = [];

async function loadCart() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');

    if (cart.length === 0) {
        renderEmptyCart();
        return;
    }

    try {
        const productIds = cart.map(item => item.id);
        const { data, error } = await supabase
            .from('products')
            .select('*')
            .in('id', productIds);

        if (error) throw error;

        products = data || [];
        cartItems = cart.map(cartItem => {
            const product = products.find(p => p.id === cartItem.id);
            return {
                ...cartItem,
                product
            };
        });

        renderCart();
    } catch (error) {
        console.error('Error loading cart:', error);
        document.getElementById('cart-content').innerHTML = '<p>Error loading cart. Please try again.</p>';
    }
}

function renderEmptyCart() {
    const html = `
        <div class="empty-cart">
            <div class="empty-cart-icon">🛒</div>
            <h2>Your Cart is Empty</h2>
            <p>Looks like you haven't added any products to your cart yet.</p>
            <a href="/products.html" class="btn-primary" style="display: inline-block; padding: 15px 40px;">
                Start Shopping
            </a>
        </div>
    `;
    document.getElementById('cart-content').innerHTML = html;
}

function renderCart() {
    const subtotal = calculateSubtotal();
    const itemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

    const html = `
        <div class="cart-layout">
            <div class="cart-items">
                <h2 style="padding: 25px; border-bottom: 1px solid var(--border-color); margin: 0;">
                    Shopping Cart (${itemCount} ${itemCount === 1 ? 'item' : 'items'})
                </h2>
                ${cartItems.map(item => renderCartItem(item)).join('')}
            </div>

            <div class="cart-summary">
                <h2>Order Summary</h2>
                <div class="summary-row">
                    <span>Subtotal (${itemCount} items):</span>
                    <span>₹${subtotal.toLocaleString('en-IN')}</span>
                </div>
                <div class="summary-row">
                    <span>Delivery:</span>
                    <span style="color: var(--success-green);">FREE (Digital)</span>
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span>₹${subtotal.toLocaleString('en-IN')}</span>
                </div>

                <button class="checkout-btn" onclick="proceedToCheckout()">
                    Proceed to Checkout
                </button>

                <a href="/products.html" class="continue-shopping">
                    ← Continue Shopping
                </a>

                <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid var(--border-color);">
                    <p style="font-size: 13px; color: var(--gray-text); line-height: 1.6;">
                        <strong>💳 Payment:</strong> Manual UPI verification<br>
                        <strong>⚡ Delivery:</strong> 2-24 hours after payment<br>
                        <strong>🔒 Secure:</strong> 100% safe transaction
                    </p>
                </div>
            </div>
        </div>
    `;

    document.getElementById('cart-content').innerHTML = html;
}

function renderCartItem(item) {
    if (!item.product) return '';

    const price = item.product.sale_price || item.product.regular_price;
    const subtotal = price * item.quantity;

    return `
        <div class="cart-item" data-item-id="${item.id}">
            <img src="${item.product.thumbnail || '/assets/img/products/placeholder.jpg'}"
                 alt="${item.product.title}"
                 class="cart-item-image"
                 onerror="this.src='/assets/img/products/placeholder.jpg'">

            <div class="cart-item-info">
                <div class="cart-item-category">${item.product.category || 'Product'}</div>
                <h3 class="cart-item-title">${item.product.title}</h3>
                <div class="cart-item-price">₹${price.toLocaleString('en-IN')}</div>

                <div class="quantity-controls">
                    <button class="quantity-btn" onclick="window.updateQuantity(${item.id}, ${item.quantity - 1})">−</button>
                    <span class="quantity-value">${item.quantity}</span>
                    <button class="quantity-btn" onclick="window.updateQuantity(${item.id}, ${item.quantity + 1})">+</button>
                </div>
            </div>

            <div class="cart-item-actions">
                <div class="cart-item-subtotal">₹${subtotal.toLocaleString('en-IN')}</div>
                <button class="remove-btn" onclick="window.removeItem(${item.id})">Remove</button>
            </div>
        </div>
    `;
}

function calculateSubtotal() {
    return cartItems.reduce((total, item) => {
        if (!item.product) return total;
        const price = item.product.sale_price || item.product.regular_price;
        return total + (price * item.quantity);
    }, 0);
}

window.updateQuantity = function(productId, newQuantity) {
    if (newQuantity < 1) {
        window.removeItem(productId);
        return;
    }

    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const item = cart.find(i => i.id == productId);

    if (item) {
        item.quantity = newQuantity;
        localStorage.setItem('cart', JSON.stringify(cart));

        const event = new Event('cartUpdated');
        window.dispatchEvent(event);

        loadCart();
    }
};

window.removeItem = function(productId) {
    if (!confirm('Remove this item from cart?')) return;

    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    cart = cart.filter(item => item.id != productId);
    localStorage.setItem('cart', JSON.stringify(cart));

    const event = new Event('cartUpdated');
    window.dispatchEvent(event);

    loadCart();
};

window.proceedToCheckout = function() {
    window.location.href = '/checkout.html';
};

document.addEventListener('DOMContentLoaded', loadCart);