import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

let allProducts = [];
let filteredProducts = [];
let currentCategory = null;

// Get URL parameters
const urlParams = new URLSearchParams(window.location.search);
const categoryParam = urlParams.get('category');
const subCategoryParam = urlParams.get('sub');

// Initialize page
document.addEventListener('DOMContentLoaded', async () => {
  await loadProducts();
  await loadCategories();
  setupEventListeners();

  if (categoryParam) {
    filterByCategory(categoryParam);
  }
});

async function loadProducts() {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('published', true)
      .order('position', { ascending: true });

    if (error) throw error;

    allProducts = data.map(product => ({
      ...product,
      images: [],
      categories: product.category ? [{ category_name: product.category }] : [],
      tags: []
    }));

    filteredProducts = [...allProducts];
    renderProducts();
    updateProductCount();
  } catch (error) {
    console.error('Error loading products:', error);
    document.getElementById('products-grid').innerHTML = `
      <div class="no-products">
        <h3>Failed to load products</h3>
        <p>Please try again later</p>
      </div>
    `;
  }
}

async function loadCategories() {
  try {
    // Get unique categories from products
    const categories = {};
    allProducts.forEach(product => {
      if (product.category) {
        if (!categories[product.category]) {
          categories[product.category] = 0;
        }
        categories[product.category]++;
      }
    });

    const categoryList = document.getElementById('category-list');
    const allCount = document.getElementById('all-count');
    if (allCount) {
      allCount.textContent = `(${allProducts.length})`;
    }

    if (categoryList) {
      Object.entries(categories)
        .sort(([a], [b]) => a.localeCompare(b))
        .forEach(([name, count]) => {
          const li = document.createElement('li');
          li.innerHTML = `
            <a href="#" data-category="${name}">
              ${name} <span>(${count})</span>
            </a>
          `;
          categoryList.appendChild(li);
        });
    }

  } catch (error) {
    console.error('Error loading categories:', error);
  }
}

function renderProducts() {
  const grid = document.getElementById('products-grid');

  if (filteredProducts.length === 0) {
    grid.innerHTML = `
      <div class="no-products">
        <h3>No products found</h3>
        <p>Try adjusting your filters or search query</p>
      </div>
    `;
    return;
  }

  grid.innerHTML = filteredProducts.map(product => {
    const primaryImage = product.images.find(img => img.is_primary) || product.images[0];
    const imageUrl = primaryImage?.image_url || product.thumbnail || '/placeholder-product.jpg';

    const regularPrice = parseFloat(product.regular_price) || 0;
    const salePrice = parseFloat(product.sale_price) || 0;
    const displayPrice = salePrice > 0 ? salePrice : regularPrice;
    const hasDiscount = salePrice > 0 && salePrice < regularPrice;

    const categoryName = product.categories[0]?.category_name || 'General';

    const discount = hasDiscount
      ? Math.round(((regularPrice - salePrice) / regularPrice) * 100)
      : 0;

    return `
      <div class="product-card" onclick="window.location.href='/product.html?id=${product.id}'">
        <img src="${imageUrl}" alt="${product.title}" class="product-image" onerror="this.src='/placeholder-product.jpg'">
        <div class="product-info">
          <div class="product-category">${categoryName}</div>
          <h3 class="product-title">${product.title}</h3>
          <div class="product-price">
            <span class="price-current">₹${displayPrice.toLocaleString('en-IN')}</span>
            ${hasDiscount ? `<span class="price-original">₹${regularPrice.toLocaleString('en-IN')}</span>` : ''}
          </div>
          ${hasDiscount ? `<span class="product-badge">${discount}% OFF</span>` : ''}
          <div class="product-actions">
            <button class="btn-add-cart" onclick="event.stopPropagation(); addToCart(${product.id})">
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function setupEventListeners() {
  // Search
  document.getElementById('search-input').addEventListener('input', (e) => {
    applyFilters();
  });

  // Price filter
  document.getElementById('price-filter').addEventListener('change', applyFilters);

  // Sort
  document.getElementById('sort-select').addEventListener('change', applySorting);

  // Category filter
  document.getElementById('category-list').addEventListener('click', (e) => {
    e.preventDefault();
    if (e.target.tagName === 'A') {
      const category = e.target.dataset.category;

      // Update active state
      document.querySelectorAll('.category-filter a').forEach(a => a.classList.remove('active'));
      e.target.classList.add('active');

      if (category) {
        filterByCategory(category);
      } else {
        currentCategory = null;
        applyFilters();
      }
    }
  });
}

function filterByCategory(category) {
  currentCategory = category;
  document.getElementById('page-title').textContent = category;
  document.getElementById('current-category').textContent = category;
  applyFilters();
}

function applyFilters() {
  const searchQuery = document.getElementById('search-input').value.toLowerCase();
  const priceRange = document.getElementById('price-filter').value;

  filteredProducts = allProducts.filter(product => {
    // Search filter
    if (searchQuery && !product.title.toLowerCase().includes(searchQuery)) {
      return false;
    }

    // Category filter
    if (currentCategory) {
      const hasCategory = product.categories.some(cat =>
        cat.category_name === currentCategory
      );
      if (!hasCategory) return false;
    }

    // Price filter
    if (priceRange) {
      const price = parseFloat(product.sale_price || product.regular_price) || 0;

      if (priceRange === '0-500' && price > 500) return false;
      if (priceRange === '500-1000' && (price < 500 || price > 1000)) return false;
      if (priceRange === '1000-5000' && (price < 1000 || price > 5000)) return false;
      if (priceRange === '5000-10000' && (price < 5000 || price > 10000)) return false;
      if (priceRange === '10000+' && price < 10000) return false;
    }

    return true;
  });

  applySorting();
  updateProductCount();
}

function applySorting() {
  const sortBy = document.getElementById('sort-select').value;

  filteredProducts.sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return (parseFloat(a.sale_price || a.regular_price) || 0) -
               (parseFloat(b.sale_price || b.regular_price) || 0);

      case 'price-high':
        return (parseFloat(b.sale_price || b.regular_price) || 0) -
               (parseFloat(a.sale_price || a.regular_price) || 0);

      case 'name':
        return a.title.localeCompare(b.title);

      case 'newest':
        return new Date(b.created_at) - new Date(a.created_at);

      case 'featured':
      default:
        if (a.is_featured && !b.is_featured) return -1;
        if (!a.is_featured && b.is_featured) return 1;
        return a.position - b.position;
    }
  });

  renderProducts();
}

function updateProductCount() {
  document.getElementById('products-count').textContent = filteredProducts.length;
}

// Add to cart function
window.addToCart = async function(productId) {
  const product = allProducts.find(p => p.id === productId);
  if (!product) return;

  // Get existing cart from localStorage
  let cart = JSON.parse(localStorage.getItem('cart') || '[]');

  // Check if product already in cart
  const existingItem = cart.find(item => item.id === productId);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({
      id: product.id,
      title: product.title,
      price: parseFloat(product.sale_price || product.regular_price) || 0,
      image: product.images[0]?.image_url || product.thumbnail,
      quantity: 1
    });
  }

  localStorage.setItem('cart', JSON.stringify(cart));

  // Update cart count in header
  updateCartCount();

  // Show feedback
  alert(`${product.title} added to cart!`);
};

function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartCountElement = document.querySelector('.cart-count');
  if (cartCountElement) {
    cartCountElement.textContent = count;
    if (count > 0) {
      cartCountElement.style.display = 'flex';
    }
  }
}

// Initialize cart count on page load
updateCartCount();
