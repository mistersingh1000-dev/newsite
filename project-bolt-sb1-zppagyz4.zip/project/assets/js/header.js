// Header JavaScript Functionality

document.addEventListener('DOMContentLoaded', function() {
    // Mobile Menu Toggle
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const mainNav = document.getElementById('mainNav');

    if (mobileMenuToggle && mainNav) {
        // Create overlay for mobile menu
        const overlay = document.createElement('div');
        overlay.className = 'mobile-menu-overlay';
        document.body.appendChild(overlay);

        mobileMenuToggle.addEventListener('click', function() {
            mobileMenuToggle.classList.toggle('active');
            mainNav.classList.toggle('active');
            overlay.classList.toggle('active');
            document.body.style.overflow = mainNav.classList.contains('active') ? 'hidden' : '';
        });

        // Close menu when clicking overlay
        overlay.addEventListener('click', function() {
            mobileMenuToggle.classList.remove('active');
            mainNav.classList.remove('active');
            overlay.classList.remove('active');
            document.body.style.overflow = '';
        });

        // Close menu when clicking a link
        const navLinks = mainNav.querySelectorAll('a');
        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                mobileMenuToggle.classList.remove('active');
                mainNav.classList.remove('active');
                overlay.classList.remove('active');
                document.body.style.overflow = '';
            });
        });
    }

    // Sticky Header on Scroll
    const mainHeader = document.getElementById('mainHeader');
    let lastScrollTop = 0;

    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        if (scrollTop > 50) {
            mainHeader.classList.add('scrolled');
        } else {
            mainHeader.classList.remove('scrolled');
        }

        lastScrollTop = scrollTop;
    });

    // Update Cart Count
    function updateCartCount() {
        const cartCount = document.getElementById('cartCount');
        if (cartCount) {
            // Get cart items from localStorage or session
            let cartItems = 0;

            // Check if localStorage has cart data
            if (typeof localStorage !== 'undefined') {
                const cart = localStorage.getItem('cart');
                if (cart) {
                    try {
                        const cartData = JSON.parse(cart);
                        cartItems = Array.isArray(cartData) ? cartData.length : 0;
                    } catch (e) {
                        cartItems = 0;
                    }
                }
            }

            cartCount.textContent = cartItems;
            cartCount.style.display = cartItems > 0 ? 'block' : 'none';
        }
    }

    // Initialize cart count
    updateCartCount();

    // Listen for cart updates
    window.addEventListener('storage', function(e) {
        if (e.key === 'cart') {
            updateCartCount();
        }
    });

    // Custom event for cart updates on same page
    window.addEventListener('cartUpdated', function() {
        updateCartCount();
    });

    // Search Form Enhancement
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            const searchInput = searchForm.querySelector('.search-input');
            if (searchInput && !searchInput.value.trim()) {
                e.preventDefault();
                searchInput.focus();
                searchInput.style.borderColor = 'var(--color-red)';
                setTimeout(() => {
                    searchInput.style.borderColor = '';
                }, 2000);
            }
        });
    }

    // Add to cart function (can be called from product pages)
    window.addToCart = function(productId, productName, price) {
        let cart = [];

        if (typeof localStorage !== 'undefined') {
            const existingCart = localStorage.getItem('cart');
            if (existingCart) {
                try {
                    cart = JSON.parse(existingCart);
                } catch (e) {
                    cart = [];
                }
            }
        }

        // Check if item already in cart
        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity = (existingItem.quantity || 1) + 1;
        } else {
            cart.push({
                id: productId,
                name: productName,
                price: price,
                quantity: 1
            });
        }

        if (typeof localStorage !== 'undefined') {
            localStorage.setItem('cart', JSON.stringify(cart));
        }

        // Dispatch custom event
        window.dispatchEvent(new Event('cartUpdated'));

        return true;
    };

    // Remove from cart function
    window.removeFromCart = function(productId) {
        if (typeof localStorage !== 'undefined') {
            let cart = [];
            const existingCart = localStorage.getItem('cart');
            if (existingCart) {
                try {
                    cart = JSON.parse(existingCart);
                } catch (e) {
                    cart = [];
                }
            }

            cart = cart.filter(item => item.id !== productId);
            localStorage.setItem('cart', JSON.stringify(cart));

            // Dispatch custom event
            window.dispatchEvent(new Event('cartUpdated'));
        }

        return true;
    };

    // Get cart items function
    window.getCartItems = function() {
        if (typeof localStorage !== 'undefined') {
            const cart = localStorage.getItem('cart');
            if (cart) {
                try {
                    return JSON.parse(cart);
                } catch (e) {
                    return [];
                }
            }
        }
        return [];
    };

    // Clear cart function
    window.clearCart = function() {
        if (typeof localStorage !== 'undefined') {
            localStorage.removeItem('cart');
            window.dispatchEvent(new Event('cartUpdated'));
        }
    };
});
