import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

async function loadFeaturedProducts() {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('published', true)
      .eq('is_featured', true)
      .order('position', { ascending: true })
      .limit(8);

    if (error) throw error;

    const featuredGrid = document.getElementById('featured-products-grid');
    if (!featuredGrid) return;

    if (!data || data.length === 0) {
      featuredGrid.innerHTML = '<p style="text-align: center; padding: 40px;">No featured products available</p>';
      return;
    }

    featuredGrid.innerHTML = data.map(product => {
      const imageUrl = product.thumbnail || '/placeholder-product.jpg';

      const regularPrice = parseFloat(product.regular_price) || 0;
      const salePrice = parseFloat(product.sale_price) || 0;
      const displayPrice = salePrice > 0 ? salePrice : regularPrice;
      const hasDiscount = salePrice > 0 && salePrice < regularPrice;

      const categoryName = product.category || 'General';

      const discount = hasDiscount
        ? Math.round(((regularPrice - salePrice) / regularPrice) * 100)
        : 0;

      return `
        <div class="product-card" onclick="window.location.href='/product.html?id=${product.id}'">
          <img src="${imageUrl}" alt="${product.title}" class="product-image" onerror="this.src='/placeholder-product.jpg'">
          <div class="product-info">
            <div class="product-category">${categoryName}</div>
            <h3 class="product-title">${product.title}</h3>
            <div class="product-price">
              <span class="price-current">₹${displayPrice.toLocaleString('en-IN')}</span>
              ${hasDiscount ? `<span class="price-original">₹${regularPrice.toLocaleString('en-IN')}</span>` : ''}
            </div>
            ${hasDiscount ? `<span class="product-badge">${discount}% OFF</span>` : ''}
          </div>
        </div>
      `;
    }).join('');

  } catch (error) {
    console.error('Error loading featured products:', error);
    const featuredGrid = document.getElementById('featured-products-grid');
    if (featuredGrid) {
      featuredGrid.innerHTML = '<p style="text-align: center; padding: 40px;">Failed to load products</p>';
    }
  }
}

async function loadBestOffers() {
  try {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('published', true)
      .not('sale_price', 'is', null)
      .gt('sale_price', 0)
      .order('created_at', { ascending: false })
      .limit(8);

    if (error) throw error;

    const offersGrid = document.getElementById('best-offers-grid');
    if (!offersGrid) return;

    if (!data || data.length === 0) {
      offersGrid.innerHTML = '<p style="text-align: center; padding: 40px;">No offers available</p>';
      return;
    }

    offersGrid.innerHTML = data.map(product => {
      const imageUrl = product.thumbnail || '/placeholder-product.jpg';

      const regularPrice = parseFloat(product.regular_price) || 0;
      const salePrice = parseFloat(product.sale_price) || 0;
      const hasDiscount = salePrice > 0 && salePrice < regularPrice;

      const categoryName = product.category || 'General';

      const discount = hasDiscount
        ? Math.round(((regularPrice - salePrice) / regularPrice) * 100)
        : 0;

      return `
        <div class="product-card" onclick="window.location.href='/product.html?id=${product.id}'">
          <img src="${imageUrl}" alt="${product.title}" class="product-image" onerror="this.src='/placeholder-product.jpg'">
          <div class="product-info">
            <div class="product-category">${categoryName}</div>
            <h3 class="product-title">${product.title}</h3>
            <div class="product-price">
              <span class="price-current">₹${salePrice.toLocaleString('en-IN')}</span>
              ${hasDiscount ? `<span class="price-original">₹${regularPrice.toLocaleString('en-IN')}</span>` : ''}
            </div>
            ${hasDiscount ? `<span class="product-badge">${discount}% OFF</span>` : ''}
          </div>
        </div>
      `;
    }).join('');

  } catch (error) {
    console.error('Error loading best offers:', error);
    const offersGrid = document.getElementById('best-offers-grid');
    if (offersGrid) {
      offersGrid.innerHTML = '<p style="text-align: center; padding: 40px;">Failed to load offers</p>';
    }
  }
}

// Load products when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    loadFeaturedProducts();
    loadBestOffers();
  });
} else {
  loadFeaturedProducts();
  loadBestOffers();
}

// Also add product card styles if not already present
const style = document.createElement('style');
style.textContent = `
  .products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 25px;
  }

  .product-card {
    background: white;
    border: 1px solid #e5e5e5;
    border-radius: 8px;
    overflow: hidden;
    transition: all 0.3s ease;
    cursor: pointer;
  }

  .product-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    transform: translateY(-4px);
  }

  .product-image {
    width: 100%;
    height: 220px;
    object-fit: cover;
    background: #f8f8f8;
  }

  .product-info {
    padding: 15px;
  }

  .product-category {
    font-size: 12px;
    color: #2563eb;
    text-transform: uppercase;
    font-weight: 600;
    margin-bottom: 5px;
  }

  .product-title {
    font-size: 16px;
    font-weight: 600;
    color: #1a1a1a;
    margin: 0 0 10px 0;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }

  .product-price {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 12px;
  }

  .price-current {
    font-size: 20px;
    font-weight: 700;
    color: #16a34a;
  }

  .price-original {
    font-size: 14px;
    color: #999;
    text-decoration: line-through;
  }

  .product-badge {
    display: inline-block;
    padding: 4px 8px;
    background: #dcfce7;
    color: #16a34a;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
  }

  @media (max-width: 640px) {
    .products-grid {
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 15px;
    }
  }
`;
document.head.appendChild(style);
