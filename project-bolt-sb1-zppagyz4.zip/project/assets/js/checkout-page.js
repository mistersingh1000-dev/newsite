import { supabase } from './supabase-client.js';

let cartItems = [];
let products = [];
let orderTotal = 0;

async function loadCheckout() {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');

    if (cart.length === 0) {
        window.location.href = '/cart.html';
        return;
    }

    try {
        const productIds = cart.map(item => item.id);
        const { data, error } = await supabase
            .from('products')
            .select('*')
            .in('id', productIds);

        if (error) throw error;

        products = data || [];
        cartItems = cart.map(cartItem => {
            const product = products.find(p => p.id === cartItem.id);
            const price = product.sale_price || product.regular_price;
            return {
                id: product.id,
                title: product.title,
                price: price,
                quantity: cartItem.quantity
            };
        });

        const orderItems = encodeURIComponent(JSON.stringify(cartItems));
        window.location.href = `/payment.html?items=${orderItems}`;

    } catch (error) {
        console.error('Error loading checkout:', error);
        document.getElementById('checkout-content').innerHTML = '<p>Error loading checkout. Please try again.</p>';
    }
}

function calculateTotal() {
    return cartItems.reduce((total, item) => {
        if (!item.product) return total;
        const price = item.product.sale_price || item.product.regular_price;
        return total + (price * item.quantity);
    }, 0);
}

function renderCheckout() {
    const itemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

    const html = `
        <div class="checkout-layout">
            <div class="checkout-form">
                <h2>Billing & Contact Details</h2>
                <form id="checkout-form" onsubmit="handleSubmit(event)">
                    <div class="form-section">
                        <h3>Contact Information</h3>
                        <div class="form-row">
                            <div class="form-group required">
                                <label for="name">Full Name</label>
                                <input type="text" id="name" name="name" required>
                            </div>
                            <div class="form-group required">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" name="email" required>
                            </div>
                        </div>
                        <div class="form-group required">
                            <label for="phone">Phone / WhatsApp Number</label>
                            <input type="tel" id="phone" name="phone" required placeholder="+91">
                        </div>
                    </div>

                    <div class="form-section">
                        <h3>Billing Address</h3>
                        <div class="form-group required">
                            <label for="address">Street Address</label>
                            <textarea id="address" name="address" rows="2" required></textarea>
                        </div>
                        <div class="form-row">
                            <div class="form-group required">
                                <label for="city">City</label>
                                <input type="text" id="city" name="city" required>
                            </div>
                            <div class="form-group required">
                                <label for="state">State</label>
                                <input type="text" id="state" name="state" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group required">
                                <label for="pincode">PIN Code</label>
                                <input type="text" id="pincode" name="pincode" required>
                            </div>
                            <div class="form-group required">
                                <label for="country">Country</label>
                                <input type="text" id="country" name="country" value="India" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-section">
                        <h3>Payment Method</h3>
                        <div class="payment-method">
                            <h4 style="margin-bottom: 15px; color: var(--primary-blue);">🇮🇳 Manual UPI Payment</h4>

                            <div class="upi-details">
                                <div class="upi-qr">
                                    <img src="/assets/img/payment/upi-qr-placeholder.png"
                                         alt="UPI QR Code"
                                         onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22300%22%3E%3Crect width=%22300%22 height=%22300%22 fill=%22%23f0f0f0%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2220%22 text-anchor=%22middle%22 dy=%22.3em%22 fill=%22%23999%22%3EUPI QR Code%3C/text%3E%3C/svg%3E'">
                                    <p style="font-size: 12px; color: var(--gray-text); margin-top: 10px;">
                                        Scan with any UPI app
                                    </p>
                                </div>

                                <div class="upi-id">
                                    UPI ID: <span style="color: var(--primary-red);">yourname@paytm</span>
                                </div>

                                <p style="font-size: 13px; color: var(--gray-text); margin-bottom: 15px;">
                                    👆 <strong>CHANGE THIS:</strong> Replace with your actual UPI ID
                                </p>

                                <div class="payment-instructions">
                                    <h4 style="margin-bottom: 10px; color: var(--primary-blue);">Payment Instructions:</h4>
                                    <ol>
                                        <li>Scan the QR code above or use UPI ID to pay <strong>₹${orderTotal.toLocaleString('en-IN')}</strong></li>
                                        <li>Complete the payment in your UPI app (PhonePe, Google Pay, Paytm, etc.)</li>
                                        <li>Copy the <strong>UPI Transaction ID</strong> from your payment confirmation</li>
                                        <li>Enter the transaction ID below</li>
                                        <li>Optionally upload payment screenshot for faster verification</li>
                                    </ol>
                                </div>
                            </div>

                            <div class="form-group required" style="margin-top: 20px;">
                                <label for="upi-txn-id">UPI Transaction ID / Reference Number</label>
                                <input type="text" id="upi-txn-id" name="upi_txn_id" required placeholder="Enter 12-digit UPI transaction ID">
                            </div>

                            <div class="form-group">
                                <label for="upi-note">Additional Note (Optional)</label>
                                <input type="text" id="upi-note" name="upi_note" placeholder="Any additional information">
                            </div>

                            <div class="form-group">
                                <label for="payment-screenshot">Upload Payment Screenshot (Optional)</label>
                                <input type="file" id="payment-screenshot" name="screenshot" accept="image/*">
                                <p style="font-size: 12px; color: var(--gray-text); margin-top: 5px;">
                                    Helps us verify your payment faster
                                </p>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="place-order-btn" id="place-order-btn">
                        Place Order - ₹${orderTotal.toLocaleString('en-IN')}
                    </button>
                </form>
            </div>

            <div class="cart-summary">
                <h2>Order Summary</h2>

                <div style="max-height: 300px; overflow-y: auto; margin: 20px 0; padding: 15px; background: var(--white); border-radius: 8px;">
                    ${cartItems.map(item => {
                        if (!item.product) return '';
                        const price = item.product.sale_price || item.product.regular_price;
                        return `
                            <div style="display: flex; gap: 15px; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid var(--border-color);">
                                <img src="${item.product.thumbnail || '/assets/img/products/placeholder.jpg'}"
                                     style="width: 60px; height: 60px; object-fit: cover; border-radius: 6px;">
                                <div style="flex: 1;">
                                    <div style="font-weight: 600; font-size: 14px; margin-bottom: 5px;">${item.product.title}</div>
                                    <div style="font-size: 13px; color: var(--gray-text);">Qty: ${item.quantity} × ₹${price.toLocaleString('en-IN')}</div>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>

                <div class="summary-row">
                    <span>Subtotal (${itemCount} items):</span>
                    <span>₹${orderTotal.toLocaleString('en-IN')}</span>
                </div>
                <div class="summary-row">
                    <span>Delivery:</span>
                    <span style="color: var(--success-green);">FREE</span>
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span>₹${orderTotal.toLocaleString('en-IN')}</span>
                </div>

                <div style="margin-top: 25px; padding: 20px; background: rgba(40, 167, 69, 0.1); border-radius: 8px;">
                    <h4 style="color: var(--success-green); margin-bottom: 10px;">✓ What Happens Next?</h4>
                    <ul style="font-size: 13px; line-height: 1.8; color: var(--gray-text); padding-left: 20px;">
                        <li>We verify your payment (2-24 hours)</li>
                        <li>You receive order confirmation email</li>
                        <li>Product access details sent via email/WhatsApp</li>
                        <li>24/7 support available</li>
                    </ul>
                </div>
            </div>
        </div>
    `;

    document.getElementById('checkout-content').innerHTML = html;
}

window.handleSubmit = async function(event) {
    event.preventDefault();

    const btn = document.getElementById('place-order-btn');
    btn.disabled = true;
    btn.textContent = 'Processing Order...';

    const formData = new FormData(event.target);
    const orderData = {
        customer_name: formData.get('name'),
        customer_email: formData.get('email'),
        customer_phone: formData.get('phone'),
        billing_address: {
            address: formData.get('address'),
            city: formData.get('city'),
            state: formData.get('state'),
            pincode: formData.get('pincode'),
            country: formData.get('country')
        },
        payment_method: 'manual_upi',
        payment_status: 'pending',
        order_status: 'pending',
        total_amount: orderTotal,
        currency: 'INR'
    };

    try {
        const orderNumber = generateOrderNumber();
        orderData.order_number = orderNumber;

        const { data: order, error: orderError } = await supabase
            .from('orders')
            .insert([orderData])
            .select()
            .single();

        if (orderError) throw orderError;

        const orderItems = cartItems.map(item => ({
            order_id: order.id,
            product_id: item.product.id,
            product_title: item.product.title,
            unit_price: item.product.sale_price || item.product.regular_price,
            quantity: item.quantity,
            subtotal: (item.product.sale_price || item.product.regular_price) * item.quantity
        }));

        const { error: itemsError } = await supabase
            .from('order_items')
            .insert(orderItems);

        if (itemsError) throw itemsError;

        const paymentData = {
            order_id: order.id,
            upi_txn_id: formData.get('upi_txn_id'),
            upi_reference_note: formData.get('upi_note') || null,
            status: 'pending'
        };

        const { error: paymentError } = await supabase
            .from('manual_payments')
            .insert([paymentData]);

        if (paymentError) throw paymentError;

        localStorage.removeItem('cart');
        localStorage.setItem('last_order_number', orderNumber);

        const event = new Event('cartUpdated');
        window.dispatchEvent(event);

        window.location.href = '/thank-you.html?order=' + orderNumber;

    } catch (error) {
        console.error('Error placing order:', error);
        alert('Error placing order. Please try again or contact support.');
        btn.disabled = false;
        btn.textContent = `Place Order - ₹${orderTotal.toLocaleString('en-IN')}`;
    }
};

function generateOrderNumber() {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `ORD${timestamp}${random}`;
}

document.addEventListener('DOMContentLoaded', loadCheckout);