import fs from 'fs';

const csvContent = fs.readFileSync('./data/wc-product-export-25-11-2025-1764088656864.csv', 'utf-8');
const lines = csvContent.split('\n');
const headers = lines[0].split(',');

const products = [];

for (let i = 1; i < lines.length; i++) {
  if (!lines[i].trim()) continue;

  // Basic CSV parsing (handles quoted fields)
  const regex = /(?:,|\n|^)("(?:(?:"")*[^"]*)*"|[^",\n]*|(?:\n|$))/g;
  const values = [];
  let match;

  while ((match = regex.exec(lines[i])) !== null) {
    if (match[1] !== undefined) {
      values.push(match[1].replace(/^"(.*)"$/, '$1').replace(/""/g, '"'));
    }
  }

  const product = {
    id: values[0],
    type: values[1],
    sku: values[2],
    name: values[4],
    published: values[5],
    featured: values[6],
    shortDescription: values[8],
    description: values[9],
    salePrice: values[26],
    regularPrice: values[27],
    categories: values[28],
    tags: values[29],
    images: values[31],
    position: values[37],
    brand: values[38]
  };

  products.push(product);
}

console.log(JSON.stringify(products, null, 2));
console.log(`\n\nTotal products parsed: ${products.length}`);
