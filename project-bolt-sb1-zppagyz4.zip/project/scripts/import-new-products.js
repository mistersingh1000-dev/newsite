import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'fs';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

function parseCSV(csvText) {
  const lines = csvText.split('\n');
  const headers = parseCSVLine(lines[0]);
  const products = [];

  for (let i = 1; i < lines.length; i++) {
    if (!lines[i].trim()) continue;

    const values = parseCSVLine(lines[i]);
    if (values.length < headers.length) continue;

    const product = {};
    headers.forEach((header, index) => {
      product[header] = values[index] || '';
    });

    products.push(product);
  }

  return products;
}

function parseCSVLine(line) {
  const result = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const nextChar = line[i + 1];

    if (char === '"' && inQuotes && nextChar === '"') {
      current += '"';
      i++;
    } else if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}

function cleanHTML(html) {
  if (!html) return '';
  return html
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractFirstImageUrl(imagesString) {
  if (!imagesString) return null;
  const urls = imagesString.split(',').map(url => url.trim());
  return urls[0] || null;
}

function generateSlug(name) {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

function transformProduct(csvProduct) {
  const title = csvProduct.Name || '';
  const longDescription = cleanHTML(csvProduct.Description || csvProduct['Short description'] || '');
  const shortDescription = cleanHTML(csvProduct['Short description'] || '');

  // Parse price
  let salePrice = parseFloat(csvProduct['Sale price']) || null;
  let regularPrice = parseFloat(csvProduct['Regular price']) || null;

  // Parse stock
  const inStock = csvProduct['In stock?'] === '1';
  const stock = parseInt(csvProduct.Stock) || (inStock ? 100 : 0);

  // Get image
  const thumbnail = extractFirstImageUrl(csvProduct.Images);

  // Get category from Categories field
  const category = csvProduct.Categories || null;

  // Get tags - convert to array
  const tagsString = csvProduct.Tags || '';
  const tags = tagsString ? tagsString.split(',').map(t => t.trim()).filter(t => t) : null;

  return {
    title: title,
    slug: generateSlug(title),
    description: longDescription,
    long_description: longDescription,
    short_description: shortDescription,
    sale_price: salePrice,
    regular_price: regularPrice,
    stock_quantity: stock,
    stock_status: inStock ? 'in_stock' : 'out_of_stock',
    thumbnail: thumbnail,
    category: category,
    tags: tags,
    sku: csvProduct.SKU || null,
    product_type: csvProduct.Type || 'simple',
    published: csvProduct.Published === '1',
    is_featured: csvProduct['Is featured?'] === '1',
    currency: 'INR',
    brand: csvProduct.Brands || null,
  };
}

async function importProducts() {
  try {
    console.log('🚀 Starting product import...\n');

    // Read CSV files
    const csv1 = readFileSync('./data/1 copy.csv', 'utf-8');
    const csv2 = readFileSync('./data/2 copy.csv', 'utf-8');

    console.log('📄 Parsing CSV files...');
    const products1 = parseCSV(csv1);
    const products2 = parseCSV(csv2);

    const allProducts = [...products1, ...products2];
    console.log(`✅ Found ${allProducts.length} products to import\n`);

    let successCount = 0;
    let errorCount = 0;

    for (const csvProduct of allProducts) {
      // Skip if no name
      if (!csvProduct.Name || !csvProduct.Name.trim()) {
        continue;
      }

      const product = transformProduct(csvProduct);

      console.log(`📦 Importing: ${product.title.substring(0, 50)}...`);

      // Check if product already exists by title
      const { data: existing } = await supabase
        .from('products')
        .select('id')
        .eq('title', product.title)
        .maybeSingle();

      if (existing) {
        console.log('   ⚠️  Product already exists, skipping...');
        continue;
      }

      // Insert product
      const { error } = await supabase
        .from('products')
        .insert([product]);

      if (error) {
        console.error('   ❌ Error:', error.message);
        errorCount++;
      } else {
        console.log('   ✅ Imported successfully');
        successCount++;
      }
    }

    console.log('\n' + '='.repeat(50));
    console.log('📊 Import Summary:');
    console.log(`✅ Successfully imported: ${successCount} products`);
    console.log(`❌ Failed: ${errorCount} products`);
    console.log('='.repeat(50));

  } catch (error) {
    console.error('❌ Import failed:', error);
    process.exit(1);
  }
}

importProducts();
