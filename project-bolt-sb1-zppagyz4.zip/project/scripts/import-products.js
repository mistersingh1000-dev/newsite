import fs from 'fs';
import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

function cleanHtml(html) {
  if (!html) return '';
  return html
    .replace(/\\r\\n/g, '\n')
    .replace(/\\"/g, '"')
    .replace(/^"|"$/g, '')
    .trim();
}

function createSlug(name) {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
}

function parsePrice(price) {
  if (!price || price === '') return null;
  const cleaned = price.replace(/[^0-9.]/g, '');
  return cleaned ? parseFloat(cleaned) : null;
}

function parseImages(imageString) {
  if (!imageString) return [];
  return imageString
    .split(',')
    .map(img => img.trim())
    .filter(img => img && img.startsWith('http'));
}

function parseCategories(categoryString) {
  if (!categoryString) return [];
  return categoryString
    .split(',')
    .map(cat => cat.trim())
    .filter(cat => cat);
}

function parseTags(tagString) {
  if (!tagString) return [];
  return tagString
    .split(',')
    .map(tag => tag.trim())
    .filter(tag => tag && !tag.startsWith('#'));
}

async function importProducts() {
  const csvContent = fs.readFileSync('./data/wc-product-export-25-11-2025-1764088656864.csv', 'utf-8');
  const lines = csvContent.split('\n');

  console.log('Starting product import...\n');

  let imported = 0;
  let skipped = 0;
  let errors = 0;

  for (let i = 1; i < lines.length; i++) {
    if (!lines[i].trim()) continue;

    try {
      // Parse CSV line (basic implementation)
      const values = [];
      let currentValue = '';
      let inQuotes = false;

      for (let j = 0; j < lines[i].length; j++) {
        const char = lines[i][j];

        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          values.push(currentValue);
          currentValue = '';
        } else {
          currentValue += char;
        }
      }
      values.push(currentValue);

      const productId = parseInt(values[0]);
      const productType = values[1];
      const sku = values[2];
      const name = values[4];
      const published = values[5] === '1';
      const featured = values[6] === '1';
      const shortDescription = cleanHtml(values[8]);
      const description = cleanHtml(values[9]);
      const salePrice = parsePrice(values[26]);
      const regularPrice = parsePrice(values[27]);
      const categoriesStr = values[28];
      const tagsStr = values[29];
      const imagesStr = values[31];
      const position = parseInt(values[37]) || 0;
      const brand = values[38];

      // Skip variations (they have parent_id in different column)
      if (productType.includes('variation')) {
        skipped++;
        continue;
      }

      if (!name || !productId) {
        skipped++;
        continue;
      }

      const slug = createSlug(name);
      const images = parseImages(imagesStr);
      const categories = parseCategories(categoriesStr);
      const tags = parseTags(tagsStr);

      // Insert product
      const { data: product, error: productError } = await supabase
        .from('products')
        .upsert({
          id: productId,
          title: name,
          slug: slug,
          product_type: productType.split(',')[0].trim(),
          sku: sku || null,
          description: description,
          short_description: shortDescription,
          regular_price: regularPrice,
          sale_price: salePrice,
          stock_quantity: 100, // Default stock
          stock_status: 'in_stock',
          published: published,
          is_featured: featured,
          brand: brand || null,
          position: position,
          thumbnail: images[0] || null
        }, {
          onConflict: 'id',
          ignoreDuplicates: false
        })
        .select()
        .maybeSingle();

      if (productError) {
        console.error(`Error inserting product ${productId}:`, productError.message);
        errors++;
        continue;
      }

      // Insert images
      if (images.length > 0) {
        const imageData = images.map((img, idx) => ({
          product_id: productId,
          image_url: img,
          position: idx,
          is_primary: idx === 0
        }));

        // Delete existing images first
        await supabase
          .from('product_images')
          .delete()
          .eq('product_id', productId);

        const { error: imageError } = await supabase
          .from('product_images')
          .insert(imageData);

        if (imageError) {
          console.error(`Error inserting images for product ${productId}:`, imageError.message);
        }
      }

      // Insert categories
      if (categories.length > 0) {
        await supabase
          .from('product_categories_new')
          .delete()
          .eq('product_id', productId);

        const categoryData = categories.map(cat => {
          const parts = cat.split('>').map(p => p.trim());
          return {
            product_id: productId,
            category_name: parts[parts.length - 1],
            parent_category: parts.length > 1 ? parts[parts.length - 2] : null
          };
        });

        const { error: catError } = await supabase
          .from('product_categories_new')
          .insert(categoryData);

        if (catError) {
          console.error(`Error inserting categories for product ${productId}:`, catError.message);
        }
      }

      // Insert tags
      if (tags.length > 0) {
        await supabase
          .from('product_tags_new')
          .delete()
          .eq('product_id', productId);

        const tagData = tags.map(tag => ({
          product_id: productId,
          tag: tag
        }));

        const { error: tagError } = await supabase
          .from('product_tags_new')
          .insert(tagData);

        if (tagError) {
          console.error(`Error inserting tags for product ${productId}:`, tagError.message);
        }
      }

      imported++;
      console.log(`✓ Imported: ${name} (ID: ${productId})`);

    } catch (err) {
      console.error(`Error processing line ${i}:`, err.message);
      errors++;
    }
  }

  console.log('\n=== Import Summary ===');
  console.log(`Successfully imported: ${imported} products`);
  console.log(`Skipped: ${skipped} products`);
  console.log(`Errors: ${errors} products`);
}

importProducts().catch(console.error);
