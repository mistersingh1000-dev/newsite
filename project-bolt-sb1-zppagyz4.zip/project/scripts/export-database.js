import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.join(__dirname, '..', '.env') });

const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

const EXPORT_DIR = path.join(__dirname, '..', 'database-export');

// Create export directory
if (!fs.existsSync(EXPORT_DIR)) {
  fs.mkdirSync(EXPORT_DIR, { recursive: true });
}

async function exportProducts() {
  console.log('Exporting products...');

  const { data, error } = await supabase
    .from('products')
    .select('*')
    .order('id');

  if (error) throw error;

  const sqlInserts = data.map(product => {
    const values = [
      product.id,
      `'${(product.title || '').replace(/'/g, "''")}'`,
      product.slug ? `'${product.slug.replace(/'/g, "''")}'` : 'NULL',
      product.description ? `'${product.description.replace(/'/g, "''")}'` : 'NULL',
      product.short_description ? `'${product.short_description.replace(/'/g, "''")}'` : 'NULL',
      product.regular_price || 'NULL',
      product.sale_price || 'NULL',
      product.sku ? `'${product.sku}'` : 'NULL',
      product.stock_status ? `'${product.stock_status}'` : 'NULL',
      `'${product.published}'`,
      product.category ? `'${product.category.replace(/'/g, "''")}'` : 'NULL',
      product.thumbnail ? `'${product.thumbnail.replace(/'/g, "''")}'` : 'NULL',
      `'${product.is_featured || false}'`,
      product.position || 0,
      product.brand ? `'${product.brand.replace(/'/g, "''")}'` : 'NULL',
      product.product_type ? `'${product.product_type.replace(/'/g, "''")}'` : 'NULL',
      product.tags ? `'${JSON.stringify(product.tags).replace(/'/g, "''")}'` : 'NULL',
      product.images ? `'${JSON.stringify(product.images).replace(/'/g, "''")}'` : 'NULL',
      `'${product.created_at}'`,
      `'${product.updated_at}'`
    ];

    return `INSERT INTO products (id, title, slug, description, short_description, regular_price, sale_price, sku, stock_status, published, category, thumbnail, is_featured, position, brand, product_type, tags, images, created_at, updated_at) VALUES (${values.join(', ')});`;
  });

  const sql = `-- Products Data Export
-- Total Products: ${data.length}
-- Generated: ${new Date().toISOString()}

${sqlInserts.join('\n')}

-- Reset sequence
SELECT setval('products_id_seq', (SELECT MAX(id) FROM products));
`;

  fs.writeFileSync(path.join(EXPORT_DIR, 'products-data.sql'), sql);
  console.log(`✓ Exported ${data.length} products`);

  // Also export as JSON
  fs.writeFileSync(
    path.join(EXPORT_DIR, 'products-data.json'),
    JSON.stringify(data, null, 2)
  );
  console.log('✓ Exported products as JSON');
}

async function exportOrders() {
  console.log('Exporting orders...');

  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .order('id');

  if (error) {
    console.log('  No orders table or no orders to export');
    return;
  }

  if (data.length === 0) {
    console.log('  No orders to export');
    return;
  }

  fs.writeFileSync(
    path.join(EXPORT_DIR, 'orders-data.json'),
    JSON.stringify(data, null, 2)
  );
  console.log(`✓ Exported ${data.length} orders`);
}

async function exportAdmins() {
  console.log('Exporting admin users...');

  const { data, error } = await supabase
    .from('admins')
    .select('*')
    .order('id');

  if (error) {
    console.log('  No admin users to export');
    return;
  }

  if (data.length === 0) {
    console.log('  No admin users to export');
    return;
  }

  // Don't export password hashes for security
  const sanitized = data.map(admin => ({
    email: admin.email,
    role: admin.role,
    created_at: admin.created_at
  }));

  fs.writeFileSync(
    path.join(EXPORT_DIR, 'admins-list.json'),
    JSON.stringify(sanitized, null, 2)
  );
  console.log(`✓ Exported ${data.length} admin users (passwords not included)`);
}

async function createSetupScript() {
  console.log('Creating setup script...');

  const setupScript = `#!/bin/bash

# CodeCraft Marketing - Database Setup Script
# This script will help you set up the database on a new Supabase instance

echo "=================================="
echo "Database Setup Script"
echo "=================================="
echo ""

# Check if Supabase CLI is installed
if ! command -v supabase &> /dev/null
then
    echo "Supabase CLI not found. Installing..."
    brew install supabase/tap/supabase
fi

echo "1. Make sure you have created a Supabase project"
echo "2. Run: supabase link --project-ref YOUR_PROJECT_REF"
echo "3. Then run the migrations:"
echo ""
echo "   supabase db push"
echo ""
echo "4. Import the products data:"
echo "   psql YOUR_DATABASE_URL < database-export/products-data.sql"
echo ""
echo "=================================="
echo "Setup Complete!"
echo "=================================="
`;

  fs.writeFileSync(path.join(EXPORT_DIR, 'setup.sh'), setupScript);
  fs.chmodSync(path.join(EXPORT_DIR, 'setup.sh'), '755');
  console.log('✓ Created setup script');
}

async function createReadme() {
  console.log('Creating README...');

  const readme = `# CodeCraft Marketing - Database Export

This package contains the complete database schema and data for the CodeCraft Marketing e-commerce platform.

## Contents

- \`products-data.sql\` - SQL file with all product data (${await getProductCount()} products)
- \`products-data.json\` - JSON export of all products
- \`orders-data.json\` - All orders (if any)
- \`admins-list.json\` - Admin user emails (passwords not included)
- \`setup.sh\` - Automated setup script

## Setup Instructions

### Option 1: Automated Setup (Recommended)

1. Create a new Supabase project at https://supabase.com
2. Copy your project reference and database URL
3. Run the setup script:
   \`\`\`bash
   ./setup.sh
   \`\`\`

### Option 2: Manual Setup

1. **Create Supabase Project**
   - Go to https://supabase.com
   - Create a new project

2. **Link to Project**
   \`\`\`bash
   supabase link --project-ref YOUR_PROJECT_REF
   \`\`\`

3. **Run Migrations**
   Copy all migration files from \`../supabase/migrations/\` to your new project:
   \`\`\`bash
   supabase db push
   \`\`\`

4. **Import Products Data**
   \`\`\`bash
   psql YOUR_DATABASE_URL < database-export/products-data.sql
   \`\`\`

5. **Update Environment Variables**
   Copy the \`.env\` file and update with your new Supabase credentials:
   \`\`\`
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_anon_key
   \`\`\`

## Database Schema

### Tables
- \`products\` - Product catalog
- \`orders\` - Customer orders
- \`order_items\` - Order line items
- \`admins\` - Admin users
- \`admin_sessions\` - Admin authentication

### Storage Buckets
- \`product-images\` - Product images (public bucket)

## Important Notes

1. **Admin Passwords**: Admin passwords are NOT included in this export for security reasons. You'll need to create new admin accounts after setup.

2. **Storage Images**: Product images are stored in Supabase Storage. The image URLs in the products table point to the current Supabase instance. You may need to re-upload images or update URLs.

3. **Environment Variables**: Don't forget to update your \`.env\` file with the new Supabase credentials.

4. **RLS Policies**: All Row Level Security policies are included in the migrations.

## Support

For issues or questions, contact:
- Email: mistersingh1000@gmail.com
- WhatsApp: +91-7009732517

## Export Date

Generated: ${new Date().toISOString()}
`;

  fs.writeFileSync(path.join(EXPORT_DIR, 'README.md'), readme);
  console.log('✓ Created README.md');
}

async function getProductCount() {
  const { count } = await supabase
    .from('products')
    .select('*', { count: 'exact', head: true });
  return count || 0;
}

async function exportDatabase() {
  try {
    console.log('Starting database export...\n');

    await exportProducts();
    await exportOrders();
    await exportAdmins();
    await createSetupScript();
    await createReadme();

    console.log('\n========================================');
    console.log('Export Complete!');
    console.log('========================================');
    console.log(`Export location: ${EXPORT_DIR}`);
    console.log('\nNext steps:');
    console.log('1. Copy the entire project folder');
    console.log('2. Review database-export/README.md for setup instructions');
    console.log('3. All migrations are in supabase/migrations/');
    console.log('========================================\n');

  } catch (error) {
    console.error('Export failed:', error);
    process.exit(1);
  }
}

exportDatabase();
