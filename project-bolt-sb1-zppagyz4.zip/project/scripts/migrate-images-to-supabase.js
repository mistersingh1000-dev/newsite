import { createClient } from '@supabase/supabase-js';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';
import * as https from 'https';
import * as http from 'http';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.join(__dirname, '..', '.env') });

// Use anon key for storage operations (bucket is public)
const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

const TEMP_DIR = path.join(__dirname, 'temp-images');
const BUCKET_NAME = 'product-images';

// Create temp directory if it doesn't exist
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

// Download image from URL
function downloadImage(url, filepath) {
  return new Promise((resolve, reject) => {
    const protocol = url.startsWith('https') ? https : http;

    protocol.get(url, (response) => {
      if (response.statusCode === 200) {
        const fileStream = fs.createWriteStream(filepath);
        response.pipe(fileStream);
        fileStream.on('finish', () => {
          fileStream.close();
          resolve();
        });
        fileStream.on('error', reject);
      } else {
        reject(new Error(`Failed to download: ${response.statusCode}`));
      }
    }).on('error', reject);
  });
}

// Get file extension from URL
function getExtensionFromUrl(url) {
  const match = url.match(/\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i);
  return match ? match[1].toLowerCase() : 'jpg';
}

// Sanitize filename
function sanitizeFilename(filename) {
  return filename
    .replace(/[^a-z0-9.-]/gi, '_')
    .replace(/__+/g, '_')
    .toLowerCase();
}

async function createStorageBucket() {
  console.log('✓ Using storage bucket: product-images');
  // Bucket is created via migration and is ready to use
}

async function migrateImages() {
  try {
    console.log('Starting image migration...\n');

    // Step 1: Create bucket
    await createStorageBucket();

    // Step 2: Get all products with external URLs
    console.log('\nFetching products with external image URLs...');
    const { data: products, error: fetchError } = await supabase
      .from('products')
      .select('id, title, thumbnail')
      .like('thumbnail', 'http%');

    if (fetchError) throw fetchError;

    console.log(`Found ${products.length} products with external URLs\n`);

    if (products.length === 0) {
      console.log('No products to migrate!');
      return;
    }

    // Step 3: Process each product
    let successCount = 0;
    let failureCount = 0;

    for (const product of products) {
      try {
        console.log(`Processing: ${product.title}`);
        console.log(`  URL: ${product.thumbnail}`);

        // Generate filename
        const ext = getExtensionFromUrl(product.thumbnail);
        const filename = sanitizeFilename(`product_${product.id}_${Date.now()}.${ext}`);
        const tempPath = path.join(TEMP_DIR, filename);

        // Download image
        console.log(`  Downloading...`);
        await downloadImage(product.thumbnail, tempPath);

        // Read file
        const fileBuffer = fs.readFileSync(tempPath);

        // Upload to Supabase Storage
        console.log(`  Uploading to Supabase...`);
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from(BUCKET_NAME)
          .upload(filename, fileBuffer, {
            contentType: `image/${ext}`,
            cacheControl: '3600',
            upsert: false
          });

        if (uploadError) throw uploadError;

        // Get public URL
        const { data: urlData } = supabase.storage
          .from(BUCKET_NAME)
          .getPublicUrl(filename);

        const publicUrl = urlData.publicUrl;

        // Update product record
        console.log(`  Updating database...`);
        const { error: updateError } = await supabase
          .from('products')
          .update({ thumbnail: publicUrl })
          .eq('id', product.id);

        if (updateError) throw updateError;

        // Clean up temp file
        fs.unlinkSync(tempPath);

        console.log(`  ✓ Success! New URL: ${publicUrl}\n`);
        successCount++;

      } catch (error) {
        console.error(`  ✗ Failed: ${error.message}\n`);
        failureCount++;
      }
    }

    // Cleanup temp directory
    if (fs.existsSync(TEMP_DIR)) {
      fs.rmSync(TEMP_DIR, { recursive: true, force: true });
    }

    // Summary
    console.log('\n========================================');
    console.log('Migration Complete!');
    console.log('========================================');
    console.log(`Total products: ${products.length}`);
    console.log(`Successful: ${successCount}`);
    console.log(`Failed: ${failureCount}`);
    console.log('========================================\n');

  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

// Run migration
migrateImages();
