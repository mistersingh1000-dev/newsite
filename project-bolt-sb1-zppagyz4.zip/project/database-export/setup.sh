#!/bin/bash

# CodeCraft Marketing - Database Setup Script
# This script will help you set up the database on a new Supabase instance

echo "=================================="
echo "Database Setup Script"
echo "=================================="
echo ""

# Check if Supabase CLI is installed
if ! command -v supabase &> /dev/null
then
    echo "Supabase CLI not found. Installing..."
    brew install supabase/tap/supabase
fi

echo "1. Make sure you have created a Supabase project"
echo "2. Run: supabase link --project-ref YOUR_PROJECT_REF"
echo "3. Then run the migrations:"
echo ""
echo "   supabase db push"
echo ""
echo "4. Import the products data:"
echo "   psql YOUR_DATABASE_URL < database-export/products-data.sql"
echo ""
echo "=================================="
echo "Setup Complete!"
echo "=================================="
