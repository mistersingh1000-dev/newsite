# CodeCraft Marketing - Database Export

This package contains the complete database schema and data for the CodeCraft Marketing e-commerce platform.

## Contents

- `products-data.sql` - SQL file with all product data (212 products)
- `products-data.json` - JSON export of all products
- `orders-data.json` - All orders (if any)
- `admins-list.json` - Admin user emails (passwords not included)
- `setup.sh` - Automated setup script

## Setup Instructions

### Option 1: Automated Setup (Recommended)

1. Create a new Supabase project at https://supabase.com
2. Copy your project reference and database URL
3. Run the setup script:
   ```bash
   ./setup.sh
   ```

### Option 2: Manual Setup

1. **Create Supabase Project**
   - Go to https://supabase.com
   - Create a new project

2. **Link to Project**
   ```bash
   supabase link --project-ref YOUR_PROJECT_REF
   ```

3. **Run Migrations**
   Copy all migration files from `../supabase/migrations/` to your new project:
   ```bash
   supabase db push
   ```

4. **Import Products Data**
   ```bash
   psql YOUR_DATABASE_URL < database-export/products-data.sql
   ```

5. **Update Environment Variables**
   Copy the `.env` file and update with your new Supabase credentials:
   ```
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_anon_key
   ```

## Database Schema

### Tables
- `products` - Product catalog
- `orders` - Customer orders
- `order_items` - Order line items
- `admins` - Admin users
- `admin_sessions` - Admin authentication

### Storage Buckets
- `product-images` - Product images (public bucket)

## Important Notes

1. **Admin Passwords**: Admin passwords are NOT included in this export for security reasons. You'll need to create new admin accounts after setup.

2. **Storage Images**: Product images are stored in Supabase Storage. The image URLs in the products table point to the current Supabase instance. You may need to re-upload images or update URLs.

3. **Environment Variables**: Don't forget to update your `.env` file with the new Supabase credentials.

4. **RLS Policies**: All Row Level Security policies are included in the migrations.

## Support

For issues or questions, contact:
- Email: mistersingh1000@gmail.com
- WhatsApp: +91-7009732517

## Export Date

Generated: 2025-11-27T17:24:54.993Z
